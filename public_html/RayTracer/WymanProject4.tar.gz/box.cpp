// Zach Wyman CPSC 2100
// Box Functions

#include "obj.h"
#include "box.h"
#include "vector.h"
#include "rt.h"

// Box Constructors

Box::Box(Vector ll, Vector ur) {
    this->ll = ll;
    this->ur = ur;
}

Box::Box(void) {
    ll = Vector(0, 0, 0);
    ur = Vector(0, 0, 0);
}

void Box::swap(double &a, double &b) {
    double temp = a;
    a = b;
    b = temp;
}

// Checks to see if the box intersects a ray
// Returns true if it does

bool Box::intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t) {
    int i;
    int index;
    int swapflag;

    double t1;
    double t2;
    t = -1000; // tnear
    double tfar = 1000;

    static Vector normalarray[6] = {
        Vector(-1.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0),
        Vector(0.0, -1.0, 0.0), Vector(0.0, 1.0, 0.0),
        Vector(0.0, 0.0, -1.0), Vector(0.0, 0.0, 1.0)
    };

    for (i = 0; i < 3; i++) {
        
        swapflag = 0;

        // Checks to see if ray is parallel

        if (ray.dir.getValue(i) == 0) {
            if ((ray.ori.getValue(i) < ll.getValue(i)) || (ray.ori.getValue(i) > ur.getValue(i))) {
                return false;
            }
        }

        t1 = (ll.getValue(i) - ray.ori.getValue(i)) / ray.dir.getValue(i);
        t2 = (ur.getValue(i) - ray.ori.getValue(i)) / ray.dir.getValue(i);

        if (t1 > t2) {
            swap(t1, t2);
            swapflag = 1;
        }

        if (t1 > t) {
            t = t1;
            index = i * 2 + swapflag;
        }

        if (t2 < tfar) {
            tfar = t2;
        }

        if (t > tfar) {
            return false;
        }

        if (tfar < 0) {
            return false;
        }
    }
    intersect = ray.ori + (ray.dir * t);
    normal = normalarray[index];

    return true;
}
