// Zach Wyman CPSC 2100
// Box Initializations

#ifndef BOX_H
#define BOX_H

#include "vector.h"
#include "obj.h"
#include "rt.h"

class Box: public Object {
private:
    Vector ll; // Lower Left Corner
    Vector ur; // Upper Right Corner
    void swap(double &a, double &b);

public:
    Box(Vector ll, Vector ur);
    Box(void);
    
    bool intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t);
};

#endif
