// Zach Wyman CPSC 2100
// Color Functions

#include "color.h"

// Color Constructors

Color::Color(double R, double G, double B) {
    this->R = R;
    this->G = G;
    this->B = B;
}

Color::Color(void) {
    R = 0.0;
    G = 0.0;
    B = 0.0;
}

Color Color::addScalar(double scale) {
    Color ret(0.0, 0.0, 0.0);

    ret.R = R + scale;
    ret.G = G + scale;
    ret.B = B + scale;

    return ret;
}

Color Color::addColor(Color color) {
    Color ret(0.0, 0.0, 0.0);

    ret.R = R + color.R;
    ret.G = G + color.G;
    ret.B = B + color.B;

    return ret;
}

Color Color::multiplyScalar(double scale) {
    Color ret(0.0, 0.0, 0.0);

    ret.R = R * scale;
    ret.G = G * scale;
    ret.B = B * scale;

    return ret;
}

Color Color::multiplyColor(Color color) {
    Color ret(0.0, 0.0, 0.0);

    ret.R = R * color.R;
    ret.G = G * color.G;
    ret.B = B * color.B;

    return ret;
}

Color Color::operator*(double scale) {
    return this->multiplyScalar(scale);
}

Color Color::operator*(Color color) {
    return this->multiplyColor(color);
}

void Color::cap(void) {
    if (R > 1.0)
        R = 1.0;

    if (G > 1.0)
        G = 1.0;

    if (B > 1.0)
        B = 1.0;
}

bool Color::checkCap(void) {
    if (R > 1.0 || G > 1.0 || B > 1.0)
        return true;
    else
        return false;
}

unsigned char Color::printR(void) {
    return (unsigned char) (R * 255); 
}

unsigned char Color::printG(void) {
    return (unsigned char) (G * 255); 
}

unsigned char Color::printB(void) {
    return (unsigned char) (B * 255); 
}

