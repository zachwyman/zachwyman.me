// Zach Wyman CPSC 2100
// Color Initializations

#ifndef COLOR_H
#define COLOR_H

class Color {
private:
    double R;
    double G;
    double B;
public:
    Color();
    Color(double R, double G, double B);

    Color addScalar(double scale);
    Color addColor(Color color);
    Color multiplyScalar(double scale);
    Color multiplyColor(Color color);
    Color operator*(double scale);
    Color operator*(Color color);
    void cap(void);
    bool checkCap(void);

    unsigned char printR(void);
    unsigned char printG(void);
    unsigned char printB(void);
};

#endif
