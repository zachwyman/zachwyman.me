// Zach Wyman CPSC 2100
// Light Functions

#include <math.h>
#include <iostream>
#include "light.h"
#include "vector.h"
#include "rt.h"
#include "scene.h"
#include "color.h"

// Light Constructors

Light::Light(Vector source, Color color) {
    this->source = source;
    this->color = color;
}

Light::Light(void) {
    Vector src(0.0, 0.0, 0.0);
    Color clr(0.0, 0.0, 0.0); 
    source = src;
    color = clr;
}

// Checks to see if the object is in a shadow

bool Light::test_shadow(SCENE_T scene, Vector intersect, int closest_obj) {
    RAY_T shadowray;

    Vector dummy_intersect;
    Vector dummy_normal;
    double dummy_t;

    int i;

    shadowray.ori = intersect;
    shadowray.dir = source - intersect;
    shadowray.dir.normalize();

    for (i = 0; i < NUM_OBJS; i++) {

        if (i != closest_obj) {

            if (scene.objs[i]->intersect(shadowray, dummy_intersect, dummy_normal, dummy_t) == true)
                return true;
        }
    }

    return false;
}
// Sets pixel color

Color Light::illuminate(SCENE_T scene, Vector intersect, Vector normal, RAY_T ray, int closest_obj) {
    Color newcolor;
    Color obj_color;

    obj_color = scene.objs[closest_obj]->getColor1();

    if (scene.objs[closest_obj]->getCheck()) {
        if((intersect.floorSummation() & 1) == 1)
            obj_color = scene.objs[closest_obj]->getColor2();
    }

    // Attenuation

    Vector L;
    L = source - intersect;
    double len = L.len();
    double atten = (1.0 / (0.002 * (len * len) + 0.02 * len + 0.2));

    if (atten > 1.0)
        atten = 1.0;

    if (test_shadow(scene, intersect, closest_obj) == true)
        return newcolor;
    

    //Diffusal Lighting

    L.normalize();

    double dot;
    dot = normal.dot(L);

    if (dot > 0) {

        newcolor = newcolor.addColor(obj_color * color * dot * atten);

        // Specular Lighting

        Vector reflection;
        reflection = L - (normal * (dot * 2));
        reflection.normalize();
        dot = reflection.dot(ray.dir);

        if (dot > 0) 
            newcolor = newcolor.addColor(color * pow(dot, 100.0) * atten);
        
    }
    return newcolor;
}
