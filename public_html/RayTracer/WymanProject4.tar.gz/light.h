// Zach Wyman CPSC 2100
// Light Initializations

#ifndef LIGHT_H
#define LIGHT_H

#include "vector.h"
#include "scene.h"
#include "color.h"

class Light {
private:
    Vector source;
    Color color; 

    bool test_shadow(SCENE_T scene, Vector intersect, int closest_obj);

public:
    Light(Vector source, Color color);
    Light(void);

    Color illuminate(SCENE_T scene, Vector intersect, Vector normal, RAY_T ray, int closest_obj);
};

#endif
