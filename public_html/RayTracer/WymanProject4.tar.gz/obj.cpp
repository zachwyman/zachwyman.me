// Zach Wyman CPSC 2100
// Object Functions

#include "obj.h"
#include "rt.h"
#include "color.h"

// Object Mutators

Color Object::getColor1(void) {
    return color1;
}

Color Object::getColor2(void) {
    return color2;
}

bool Object::getCheck(void) {
    return checkerboard;
}

double Object::getReflection(void) {
    return reflection;
}

void Object::setColor1(Color color) {
    color1 = color;
}

void Object::setColor2(Color color) {
    color2 = color;
}

void Object::setCheckerboard(bool check) {
    checkerboard = check;
}

void Object::setReflection(double reflect) {
    reflection = reflect;
}
