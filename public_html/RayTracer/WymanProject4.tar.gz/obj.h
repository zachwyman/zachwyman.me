// Zach Wyman CPSC 2100
// Object Initializations

#ifndef OBJECT_H
#define OBJECT_H
    
#include "rt.h"
#include "color.h"

class Object {
private:
    Color color1;
    Color color2;
    bool checkerboard;
    double reflection;

public:
    Color getColor1(void);
    Color getColor2(void);
    bool getCheck(void);
    double getReflection(void);

    void setColor1(Color color);
    void setColor2(Color color);
    void setCheckerboard(bool check);
    void setReflection(double reflect);

    virtual bool intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t) {};
};

#endif
