// Zach Wyman CPSC 2100
// Plane Functions

#include "plane.h"
#include "vector.h"
#include "rt.h"

// Plane Constructors

Plane::Plane(double D, Vector normal) {
    this->normal = normal;
    this->D = D;
}

// Checks to see if the plane intersects a ray
// Returns 1 if it does

bool Plane::intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t) {
    double dotdir;
    double dotori;

    dotdir = ray.dir.dot(this->normal); 
    dotori = ray.ori.dot(this->normal); 

    if(dotdir == 0) {
    	return false;
    }

    t = - (dotori + D) / dotdir;

    if (t < 0) {
    	return false;
    }

    // Sets the intersection point and normal vectors based on the intersection

    intersect = ray.ori + (ray.dir * t);
    normal = this->normal;
    
    return true;
}
