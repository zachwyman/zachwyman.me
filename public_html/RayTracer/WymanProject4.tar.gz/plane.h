// Zach Wyman CPSC 2100
// Plane Initializations

#ifndef PLANE_H
#define PLANE_H

#include "vector.h"
#include "rt.h"
#include "obj.h"

class Plane: public Object {
private:
    double D;
    Vector normal;

public:
    Plane(double D, Vector normal);

    bool intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t);
};

#endif
