// Zach Wyman CPSC 2100
// Ray Tracer Functions and Main

#include <cmath>
#include <fstream>
#include <iostream>
#include "vector.h"
#include "obj.h"
#include "sphere.h"
#include "plane.h"
#include "box.h"
#include "light.h"
#include "rt.h"
#include "scene.h"
#include "color.h"

using namespace std;

Color do_lighting(SCENE_T scene, Vector intersect, Vector normal, RAY_T ray, int closest_obj) {
    Color newcolor;
    Color obj_color;
    obj_color = scene.objs[closest_obj]->getColor1();

    if (scene.objs[closest_obj]->getCheck()) {
        if((intersect.floorSummation() & 1) == 1)
            obj_color = scene.objs[closest_obj]->getColor2();
    }

    // Ambient Lighting

    newcolor = obj_color * 0.1;

    int i; // Counter
    for(i = 0; i < NUM_LIGHTS; i++) {
        newcolor = newcolor.addColor(scene.light[i].illuminate(scene, intersect, normal, ray, closest_obj));
    }

    return newcolor;
}

// Cycles through all of the objects in the scene
// Returns a color based on the closest object

Color trace(SCENE_T scene, RAY_T ray, int depth, int current_obj) {
    Vector intersect;
    Vector normal;
    double t;

    Vector closest_normal(0.0, 0.0, 0.0);
    Vector closest_intersect(0.0, 0.0, 0.0);
    double closest_t;
    int closest_obj;
    int i;

    closest_t = 1000.0;
    closest_obj = -2;

    Color return_color(0.0, 1.0, 0.0);
    Color local_color(0.0, 0.0, 0.0);
    Color reflection_color(0.0, 0.0, 0.0);
    if (depth == 5)
        return return_color;

    // Cycles through all of the objects to find the closest one

    for (i = 0; i < NUM_OBJS; i++) {

        if (i != current_obj) {

            if (scene.objs[i]->intersect(ray, intersect, normal, t) == true) {
            
                if (t < closest_t) {
                    closest_t = t;
                    closest_intersect = intersect;
                    closest_normal = normal;
                    closest_obj = i;
                } 
            }
        }
    }

    // Colors the pixel based on the closest object
    


    if (closest_obj >= 0) {

        double refl = scene.objs[closest_obj]->getReflection();

        if (refl > 0.0) {
            RAY_T reflected_ray;

            reflected_ray.ori = closest_intersect;
            reflected_ray.dir = ray.dir - (closest_normal * closest_normal.dot(ray.dir) * 2.0);
            reflected_ray.dir.normalize();

            reflection_color = trace(scene, reflected_ray, depth + 1, closest_obj);
            if (refl < 1) {
                local_color = do_lighting(scene, closest_intersect, closest_normal, ray, closest_obj);
                return_color = (reflection_color * refl).addColor(local_color * (1.0 - refl));
            }

        }
        else {
            return_color = do_lighting(scene, closest_intersect, closest_normal, ray, closest_obj);
        }
    }

    // Sets the background color

    else {
        Color background(0.3, 0.3, 0.5);
        return background;
    }
    
    return return_color;

}

void init(SCENE_T *scene) {
    scene->objs = new Object*[NUM_OBJS];
    scene->light = new Light[NUM_LIGHTS];

    Vector *vector = new Vector(0.5, 0.8, 4.0);
    Color *color = new Color(0.8, 0.0, 0.0);
    Sphere *sphere = new Sphere(0.5, *vector);
    sphere->setColor1(*color);
    sphere->setCheckerboard(false);
    sphere->setReflection(0.7);
    scene->objs[0] = sphere;

    vector = new Vector(-0.5, 0.15, 4.2);
    color = new Color(0.0, 0.8, 0.0);
    sphere = new Sphere(0.6, *vector);
    sphere->setColor1(*color);
    sphere->setCheckerboard(false);
    sphere->setReflection(0.0);
    scene->objs[1] = sphere;

    vector = new Vector(0.0, 1.0, 0.0);
    color = new Color(1.0, 1.0, 1.0);
    Plane *plane = new Plane(0.9, *vector);
    plane->setColor1(*color);
    color = new Color(0.0, 0.0, 0.0);
    plane->setColor2(*color);
    plane->setCheckerboard(true);
    plane->setReflection(0.1);
    scene->objs[2] = plane;

    vector = new Vector(0.3, -0.6, 2.3);
    Vector *vector2 = new Vector(0.7, -0.2, 3.0);
    color = new Color(0.0, 0.0, 1.0);
    Box *box = new Box(*vector, *vector2);
    box->setColor1(*color);
    box->setCheckerboard(false);
    box->setReflection(0.0);
    scene->objs[3] = box;

    vector = new Vector(-10.0, 10.0, -5.0);
    color = new Color(0.7, 0.7, 0.7);
    Light *light = new Light(*vector, *color);
    scene->light[0] = *light; 

    vector = new Vector(0.0, 10.0, -10.0);
    color = new Color(1.0, 1.0, 1.0);
    light = new Light(*vector, *color);
    scene->light[1] = *light;   

    // Sets the starting points for the arbitrary aspect ratio

    if (X_RES > Y_RES) {
        scene->xstart = - (X_RES / Y_RES) / 2;
        scene->ystart = 0.5;
        scene->smaller_pixel = Y_RES;
    }
    else {
        scene->xstart = - 0.5;
        scene->ystart = (Y_RES / X_RES) / 2;
        scene->smaller_pixel = X_RES;
    }
}

int main() {
    std::ofstream myfile("img.ppm");

    SCENE_T scene;
    init(&scene);

    Color newcolor(0.0, 0.0, 0.0);
    RAY_T ray;
    int x;
    int y;

    // Prints the beginning of the ppm file
    if (myfile)
        myfile << "P6" << std::endl << X_RES << " " << Y_RES << std::endl << 255 << std::endl;
    else
        std::cout << "File I/O Error" << std::endl;

    // Cycles through every pixel

    for (y = 0; y < Y_RES; y++) {
        for (x = 0; x < X_RES; x++) {
            ray.ori.setX(0.0);
            ray.ori.setY(0.0);
            ray.ori.setZ(0.0);

            ray.dir.setX(scene.xstart + ( (double) x / scene.smaller_pixel));
            ray.dir.setY(scene.ystart - ( (double) y / scene.smaller_pixel));
            ray.dir.setZ(1.0);
    
            ray.dir.normalize();

            newcolor = trace(scene, ray, 0, -1);
            
            // Caps the color values

            newcolor.cap();
            
            // Prints the color values to the ppm file

            myfile << newcolor.printR() << newcolor.printG() << newcolor.printB();

        }
    }

    myfile.close();
    return 0;
}
