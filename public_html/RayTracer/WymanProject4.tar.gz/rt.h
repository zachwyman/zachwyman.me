// Zach Wyman CPSC 2100
// RayTracer Initializations

#ifndef RT_H
#define RT_H

#include "vector.h"

#define NUM_OBJS 4  // Change based on number of objects
#define NUM_LIGHTS 2 // Change based on number of lights
#define X_RES 1024.0 // Change for X Resolution
#define Y_RES 728.0 // Change for Y Resolution

typedef struct {
    Vector ori;
    Vector dir;
} RAY_T;

#endif
