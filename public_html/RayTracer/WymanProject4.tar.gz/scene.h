// Zach Wyman CPSC 2100
// Scene Type

#ifndef SCENE_H
#define SCENE_H

#include "obj.h"
	
class Light;

typedef struct SCENE_T {
   Object **objs;
   int num_objects;
   int num_lights;
   Light *light;
   double xstart;
   double ystart;
   double smaller_pixel;
} SCENE_T;

#endif