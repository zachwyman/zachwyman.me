// Zach Wyman CPSC 2100
// Sphere Functions

#include <math.h>
#include "sphere.h"
#include "vector.h"
#include "rt.h"

// Sphere Constructors

Sphere::Sphere(double radius, Vector center) {
    this->center = center;
    this->radius = radius;
}

// Sphere Mutators

void Sphere::setRadius(double rad) {
    radius = rad;
}

void Sphere::setCenter(Vector ctr) {
    center = ctr;
}

// Checks to see if there is an intersection between the sphere and the ray
// Returns 1 if there is an intersection

bool Sphere::intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t) {
    
    // Sets the A, B, and C values for the quadratic formula

    double A = 1.0;

    double B = 2.0 * (ray.dir * (ray.ori - center)).summation();

    double C = ((ray.ori - center) * (ray.ori - center)).summation() - (radius * radius);


    // Calculates the discriminate and then checking to make sure it's positive

    double discrim = (B * B - (4.0 * A * C));
    if (discrim < 0) {
        return false;
    }

    double t1 = (-B + sqrt(discrim)) / (2.0 * A);
    double t2 = (-B - sqrt(discrim)) / (2.0 * A);

    if (t1 < 0 && t2 < 0) {
        return false;
    }   

    if (t1 < 0) {
        t = t2;
    }

    else if (t2 < 0 || t2 > t1) {
        t = t1;
    }

    else {
        t = t2;
    }

    // Sets the intersection point and the normal vector based on the intersection

    intersect = ray.ori + (ray.dir * t);
    normal = (intersect - center) / radius;

    return true;
}
