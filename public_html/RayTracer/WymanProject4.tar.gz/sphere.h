// Zach Wyman CPSC 2100
// Sphere Initializations

#ifndef SPHERE_H
#define SPHERE_H

#include "vector.h"
#include "rt.h"
#include "obj.h"

class Sphere: public Object {
private:
    double radius;
    Vector center;

public:
    Sphere(double radius, Vector center);

    void setRadius(double rad);
    void setCenter(Vector ctr);
    
    bool intersect(RAY_T ray, Vector &intersect, Vector &normal, double &t);
};

#endif
