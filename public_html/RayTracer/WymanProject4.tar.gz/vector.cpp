// Zach Wyman CPSC 2100
// Vector Functions

#include <cmath>
#include "vector.h"

// Vector Constructors

Vector::Vector(double x, double y, double z) {
    this->x = x;
    this->y = y;
    this->z = z;
}

Vector::Vector(void) {
    x = 0.0;
    y = 0.0;
    z = 0.0;
}

// Vector Mutators

void Vector::setX(double x) {
    this->x = x;
}

void Vector::setY(double y) {
    this->y = y;
}

void Vector::setZ(double z) {
    this->z = z;
}

void Vector::setValue(double value, int plane) {
    if (plane == 0) 
        x = value;
    
    if (plane == 1)
        y = value;
    
    if (plane == 2)
        z = value;
}

double Vector::getValue(int plane) {
    if (plane == 0) 
        return x;
    
    if (plane == 1)
        return y;

    if (plane == 2)
        return z;
}

// Adds two vectors together

Vector Vector::add(Vector v) {
    Vector ret(0.0, 0.0, 0.0);

    ret.x = this->x + v.x;
    ret.y = this->y + v.y;
    ret.z = this->z + v.z;

    return ret;
}

Vector Vector::operator+(Vector v) {
    Vector ret(0.0, 0.0, 0.0);
    
    ret = this->add(v);

    return ret;
}

// Returns the sum of all the components

double Vector::summation(void) {
    double ret;

    ret = x + y + z;

    return ret;
}

int Vector::floorSummation(void) {
    int ret;

    ret = (int)floor(x) + (int)floor(y) + (int)floor(z);

    return ret;
}

// Subtracts the parameter vector

Vector Vector::subtract(Vector v) {
    Vector ret(0.0, 0.0, 0.0);

    ret.x = this->x - v.x;
    ret.y = this->y - v.y;
    ret.z = this->z - v.z;

    return ret;
}

Vector Vector::operator-(Vector v) {
    Vector ret(0.0, 0.0, 0.0);
	
	ret = this->subtract(v);

	return ret;
}

// Multiplies all the vector values by a number

Vector Vector::scale(double scale) {
    Vector ret(0.0, 0.0, 0.0);

    ret.x = x * scale;
    ret.y = y * scale;
    ret.z = z * scale;

    return ret;
}

Vector Vector::operator*(double scale) {
    Vector ret(0.0, 0.0, 0.0);

	ret = this->scale(scale);

	return ret;
}

// Multiplies the vector by another vector

Vector Vector::multiply(Vector v) {
    Vector ret(0.0, 0.0, 0.0);

    ret.x = x * v.x;
    ret.y = y * v.y;
    ret.z = z * v.z;

    return ret;
}

Vector Vector::operator*(Vector v) {
    Vector ret(0.0, 0.0, 0.0);

    ret = this->multiply(v);

    return ret;
}

// Divides the vector by a scalar number

Vector Vector::divide(double scale) {
    Vector ret(0.0, 0.0, 0.0);

    ret.x = x / scale;
    ret.y = y / scale;
    ret.z = z / scale;

    return ret;
}

Vector Vector::operator/(double scale) {
    Vector ret(0.0, 0.0, 0.0);

    ret = this->divide(scale);

    return ret;
}

// Finds the dot product of two vectors

double Vector::dot(Vector v) {
    double dot = (this->x * v.x) + (this->y * v.y) + (this->z * v.z);
    return dot;
}

// Returns the length of the vector

double Vector::len(void) {
    double len = sqrt(x*x + y*y + z*z);
    return len;
}

// Normalizes the vector

void Vector::normalize(void) {
    double len = this->len();

    x = x / len;
    y = y / len;
    z = z / len;
}
