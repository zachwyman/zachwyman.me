// Zach Wyman CPSC 2100
// Vector Initializations

#ifndef VECTOR_H
#define VECTOR_H

class Vector {
private:
    double x, y, z;

public:
    Vector(double x, double y, double z);
    Vector(void);

    void setX(double x);
    void setY(double y);
    void setZ(double z);

    void setValue(double value, int plane);
    double getValue(int plane);

    Vector add(Vector v);    
    Vector operator+(Vector v);
    Vector subtract(Vector v1);
    Vector operator-(Vector v);
    Vector scale(double scale);
    Vector operator*(double scale);
    Vector multiply(Vector v);
    Vector operator*(Vector v);
    Vector divide(double scale);
    Vector operator/(double scale);
    double summation(void);
    int floorSummation(void);
    double dot(Vector v);
    double len(void);    
    void normalize(void);
};

#endif
